package com.ambienttranslator.offline;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.util.Log;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.common.model.RemoteModelManager;
import com.google.mlkit.nl.translate.TranslateRemoteModel;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;
import com.google.mlkit.nl.translate.Translation;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.Set;

public class MainActivity extends Activity {
    private static WeakReference<MainActivity> current = new WeakReference<>(null);
    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView web;
    private Intent requestedStart;
    private static final int MIC_PERMISSION_REQUEST = 301;
    private boolean loaded = false;
    private static final String TAG = "AmbientTranslator";
    private static boolean crashRecorderInstalled = false;
    private boolean modelDownloadInFlight = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        installCrashRecorder();
        getWindow().setStatusBarColor(0xff081320);
        getWindow().setNavigationBarColor(0xff081320);
        current = new WeakReference<>(this);
        web = new WebView(this);
        web.setBackgroundColor(0xff081320);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                loaded = true;
                refreshAll();
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 302);
        }
    }

    private void installCrashRecorder() {
        if (crashRecorderInstalled) return;
        crashRecorderInstalled = true;
        final Context appContext = getApplicationContext();
        final Thread.UncaughtExceptionHandler prior = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                appContext.getSharedPreferences("ambient", MODE_PRIVATE).edit()
                    .putString("last_error", "Crash on " + thread.getName() + ": " +
                        Log.getStackTraceString(throwable).substring(0,
                            Math.min(4500, Log.getStackTraceString(throwable).length())))
                    .commit();
            } catch (Throwable ignored) {}
            if (prior != null) prior.uncaughtException(thread, throwable);
        });
    }

    private void refreshAll() {
        if (!loaded) return;
        emit(ListeningService.snapshot(this));
        loadPacks();
    }

    public static void emit(JSONObject event) {
        MainActivity activity = current.get();
        if (activity == null) return;
        activity.main.post(() -> {
            if (!activity.loaded || activity.web == null) return;
            String expression = "window.NativeEvents && window.NativeEvents.onEvent(" + JSONObject.quote(event.toString()) + ");";
            activity.web.evaluateJavascript(expression, null);
        });
    }
    public static JSONObject event(String type, String message) {
        JSONObject obj = new JSONObject();
        try { obj.put("type", type); obj.put("text", message); } catch (Exception ignored) {}
        return obj;
    }

    private void loadPacks() {
        RemoteModelManager.getInstance().getDownloadedModels(TranslateRemoteModel.class)
            .addOnSuccessListener(models -> {
                JSONObject output = new JSONObject();
                JSONArray items = new JSONArray();
                String[] codes = new String[]{"es", "fr", "de", "it", "pt", "zh", "ja", "ko", "ar", "hi", "ru", "nl", "tr", "pl", "sv", "vi", "id", "th", "uk", "bn"};
                try {
                    output.put("type", "packs");
                    for (String code : codes) {
                        boolean yes = false;
                        for (TranslateRemoteModel m : models) if (code.equals(m.getLanguage())) yes = true;
                        JSONObject item = new JSONObject(); item.put("code", code); item.put("installed", yes); items.put(item);
                    }
                    output.put("models", items);
                } catch(Exception ignored) {}
                emit(output);
            }).addOnFailureListener(err -> emit(event("error", "Cannot inspect language packs: " + err.getMessage())));
    }

    // User-initiated only. Explicitly check connectivity, then fall back to the
    // Translator API if RemoteModelManager refuses the request on a device.
    private void download(String language, boolean wifi) {
        main.post(() -> {
            String code = language == null ? "" : language.trim().toLowerCase(java.util.Locale.ROOT);
            String recognized = TranslateLanguage.fromLanguageTag(code);
            if (recognized == null || "en".equals(code)) {
                emit(packEvent("pack_error", code, "That language pack is not supported by ML Kit."));
                return;
            }
            if (modelDownloadInFlight) {
                emit(packEvent("pack_error", code, "Another download is running. Try again when it finishes."));
                return;
            }
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            Network network = cm == null ? null : cm.getActiveNetwork();
            NetworkCapabilities capabilities = cm == null || network == null ? null : cm.getNetworkCapabilities(network);
            boolean internet = capabilities != null && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
            boolean wifiConnected = capabilities != null && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
            if (!internet) {
                emit(packEvent("pack_error", code, "Connect to the internet once to download the translation model. Already downloaded models work offline."));
                return;
            }
            if (wifi && !wifiConnected) {
                emit(packEvent("pack_error", code, "Wi-Fi-only is enabled. Connect to Wi-Fi, or turn off Wi-Fi-only to use mobile data."));
                return;
            }
            modelDownloadInFlight = true;
            emit(packEvent("pack_downloading", code, "Downloading " + code + " translation model… Leave the app open and keep internet on."));
            DownloadConditions.Builder builder = new DownloadConditions.Builder();
            if (wifi) builder.requireWifi();
            DownloadConditions conditions = builder.build();
            try {
                TranslateRemoteModel model = new TranslateRemoteModel.Builder(recognized).build();
                RemoteModelManager.getInstance().download(model, conditions)
                    .addOnSuccessListener(v -> finishDownload(code))
                    .addOnFailureListener(err -> fallbackDownload(code, conditions, err));
            } catch (RuntimeException e) {
                fallbackDownload(code, conditions, e);
            }
        });
    }
    private void fallbackDownload(String code, DownloadConditions conditions, Exception initial) {
        emit(packEvent("pack_downloading", code, "Trying an alternate model download method…"));
        try {
            String src = TranslateLanguage.fromLanguageTag(code);
            Translator translator = Translation.getClient(new TranslatorOptions.Builder()
                .setSourceLanguage(src).setTargetLanguage(TranslateLanguage.ENGLISH).build());
            translator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener(v -> { translator.close(); finishDownload(code); })
                .addOnFailureListener(err -> {
                    translator.close(); modelDownloadInFlight = false;
                    String detail = String.valueOf(err.getMessage());
                    Log.e(TAG, "ML Kit download failed", err);
                    emit(packEvent("pack_error", code,
                        "Download failed (" + err.getClass().getSimpleName() + "): " + detail +
                        ". Check connectivity, storage, and Google Play services, then retry. Wi-Fi-only can be disabled."));
                });
        } catch (Exception ex) {
            modelDownloadInFlight = false;
            emit(packEvent("pack_error", code, "Translation download could not start: " + ex.getMessage()));
        }
    }
    private void finishDownload(String code) {
        modelDownloadInFlight = false;
        emit(packEvent("pack_installed", code, "Model downloaded. This language is now available offline."));
        loadPacks();
    }
    private void remove(String language) {
        main.post(() -> {
            TranslateRemoteModel model = new TranslateRemoteModel.Builder(language).build();
            RemoteModelManager.getInstance().deleteDownloadedModel(model)
                .addOnSuccessListener(v -> { emit(packEvent("pack_removed", language, "Translation pack removed.")); loadPacks(); })
                .addOnFailureListener(err -> emit(packEvent("pack_error", language, "Cannot remove pack: " + err.getMessage())));
        });
    }
    private JSONObject packEvent(String type, String code, String text) {
        JSONObject obj = event(type, text);
        try {obj.put("code", code);}catch(Exception ignored){}
        if ("pack_error".equals(type))
            getSharedPreferences("ambient", MODE_PRIVATE).edit().putString("last_error",text).apply();
        return obj;
    }
    private void sendService(String action) {
        Intent intent = new Intent(this, ListeningService.class).setAction(action);
        try { startService(intent); }
        catch (RuntimeException e) { reportError("Cannot communicate with listening service", e); }
    }
    private void startListening(String src, String dst, boolean speak, String voice, double speed) {
        Intent intent = new Intent(this, ListeningService.class).setAction(ListeningService.ACTION_START);
        intent.putExtra("source", src); intent.putExtra("target", dst);
        intent.putExtra("speak", speak); intent.putExtra("voice", voice); intent.putExtra("speed", (float)speed);
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestedStart = intent;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION_REQUEST);
        } else {
            launchListening(intent);
        }
    }
    private void launchListening(Intent intent) {
        try { startForegroundService(intent); }
        catch (RuntimeException e) { reportError("Microphone service cannot start", e); }
    }
    private void reportError(String message, Throwable error) {
        Log.e(TAG, message, error);
        String detail = message + ": " + error.getClass().getSimpleName() + " · " + String.valueOf(error.getMessage());
        getSharedPreferences("ambient", MODE_PRIVATE).edit().putString("last_error", detail).apply();
        emit(event("error", detail));
    }
    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == MIC_PERMISSION_REQUEST) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED && requestedStart != null)
                launchListening(requestedStart);
            else emit(event("error", "Microphone permission is required to listen."));
            requestedStart = null;
        }
    }
    @Override protected void onResume() {super.onResume(); current = new WeakReference<>(this); if(loaded)refreshAll();}
    @Override protected void onDestroy() { if (current.get() == this) current.clear(); if(web != null){web.removeJavascriptInterface("Android");web.destroy();web=null;} super.onDestroy();}

    final class Bridge {
        @JavascriptInterface public String diagnostics() {
            return "Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")" +
                "\nMic permission: " + (checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED) +
                "\nRecent error: " + getSharedPreferences("ambient", MODE_PRIVATE).getString("last_error", "none") +
                "\nTip: If it still force-closes, collect Logcat filtered by AndroidRuntime and AmbientTranslator.";
        }
        @JavascriptInterface public void getPacks() {main.post(MainActivity.this::loadPacks);}
        @JavascriptInterface public void downloadPack(String code, boolean wifi) { download(code, wifi); }
        @JavascriptInterface public void removePack(String code) { remove(code); }
        @JavascriptInterface public void sync() {main.post(MainActivity.this::refreshAll);}
        @JavascriptInterface public void start(String src, String dst, boolean speak, String voice, double speed) {
            main.post(() -> startListening(src, dst, speak, voice, speed));
        }
        @JavascriptInterface public void stop() {main.post(() -> sendService(ListeningService.ACTION_STOP));}
        @JavascriptInterface public void pause() {main.post(() -> sendService(ListeningService.ACTION_PAUSE));}
        @JavascriptInterface public void resume() {main.post(() -> sendService(ListeningService.ACTION_RESUME));}
        @JavascriptInterface public void replay() {main.post(() -> sendService(ListeningService.ACTION_REPLAY));}
        @JavascriptInterface public void clear() { main.post(() -> { getSharedPreferences("ambient",MODE_PRIVATE).edit().remove("history").apply(); emit(event("history_cleared", "History cleared")); }); }
    }
}
