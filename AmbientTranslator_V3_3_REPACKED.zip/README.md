# Ambient Translator V3.3 - Android project

This is Android SOURCE CODE, not an installable APK. Do not try to install the ZIP on your phone.

## GitHub Actions (existing workflow)

1. Upload this file to the root of `riotunrated-byte/AmbientTranslator` on branch `main`.
2. Keep this exact filename: `AmbientTranslator_V3_3_Android.zip`.
3. Commit the upload. The existing `.github/workflows/build-v3-3.yml` in GitHub will build it.
4. Open GitHub Actions > Build Ambient Translator V3.3 Stability Update.
5. After a successful run, open the artifact `AmbientTranslator-V3.3-APK`, extract the `app-debug.apk`, then install it.

## About V3.3

- Bundled Spanish Vosk speech-recognition model is downloaded by the GITHUB BUILD RUNNER, not by this ZIP. 
- Spanish-to-English text translation still needs a one-time model download from Google ML Kit on the phone.
- The new UI has revised Wi-Fi-only handling, model status reporting, microphone service error handling and diagnostics.
- Compilation with GitHub Actions has not yet been verified for this specific V3.3 code version.

Build tools: Java 17, Gradle 8.9, Android SDK 35. See `.github/workflows/build-ambient-translator.yml` inside the archive for the preexisting build recipe. The standalone GitHub workflow `build-v3-3.yml` already committed to the repository is authoritative for this upload.
