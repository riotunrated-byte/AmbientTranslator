package com.ambienttranslator.offline;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.common.model.RemoteModelManager;
import com.google.mlkit.nl.translate.TranslateRemoteModel;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.Set;

public class MainActivity extends Activity {
    private static WeakReference<MainActivity> current = new WeakReference<>(null);
    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView web;
    private Intent requestedStart;
    private static final int MIC_PERMISSION_REQUEST = 301;
    private boolean loaded = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff081320);
        getWindow().setNavigationBarColor(0xff081320);
        current = new WeakReference<>(this);
        web = new WebView(this);
        web.setBackgroundColor(0xff081320);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                loaded = true;
                refreshAll();
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 302);
        }
    }

    private void refreshAll() {
        if (!loaded) return;
        emit(ListeningService.snapshot(this));
        loadPacks();
    }

    public static void emit(JSONObject event) {
        MainActivity activity = current.get();
        if (activity == null) return;
        activity.main.post(() -> {
            if (!activity.loaded || activity.web == null) return;
            String expression = "window.NativeEvents && window.NativeEvents.onEvent(" + JSONObject.quote(event.toString()) + ");";
            activity.web.evaluateJavascript(expression, null);
        });
    }
    public static JSONObject event(String type, String message) {
        JSONObject obj = new JSONObject();
        try { obj.put("type", type); obj.put("text", message); } catch (Exception ignored) {}
        return obj;
    }

    private void loadPacks() {
        RemoteModelManager.getInstance().getDownloadedModels(TranslateRemoteModel.class)
            .addOnSuccessListener(models -> {
                JSONObject output = new JSONObject();
                JSONArray items = new JSONArray();
                String[] codes = new String[]{"es", "fr", "de", "it", "pt", "zh", "ja", "ko", "ar", "hi", "ru", "nl", "tr", "pl", "sv", "vi", "id", "th", "uk", "bn"};
                try {
                    output.put("type", "packs");
                    for (String code : codes) {
                        boolean yes = false;
                        for (TranslateRemoteModel m : models) if (code.equals(m.getLanguage())) yes = true;
                        JSONObject item = new JSONObject(); item.put("code", code); item.put("installed", yes); items.put(item);
                    }
                    output.put("models", items);
                } catch(Exception ignored) {}
                emit(output);
            }).addOnFailureListener(err -> emit(event("error", "Cannot inspect language packs: " + err.getMessage())));
    }

    private void download(String language, boolean wifi) {
        main.post(() -> {
            emit(packEvent("pack_downloading", language, "Downloading " + language + " translation pack…"));
            TranslateRemoteModel model = new TranslateRemoteModel.Builder(language).build();
            DownloadConditions.Builder builder = new DownloadConditions.Builder();
            if (wifi) builder.requireWifi();
            RemoteModelManager.getInstance().download(model, builder.build())
                .addOnSuccessListener(v -> { emit(packEvent("pack_installed", language, "Translation pack saved. Ready without internet.")); loadPacks(); })
                .addOnFailureListener(err -> emit(packEvent("pack_error", language, "Download failed: " + err.getMessage())));
        });
    }
    private void remove(String language) {
        main.post(() -> {
            TranslateRemoteModel model = new TranslateRemoteModel.Builder(language).build();
            RemoteModelManager.getInstance().deleteDownloadedModel(model)
                .addOnSuccessListener(v -> { emit(packEvent("pack_removed", language, "Translation pack removed.")); loadPacks(); })
                .addOnFailureListener(err -> emit(packEvent("pack_error", language, "Cannot remove pack: " + err.getMessage())));
        });
    }
    private JSONObject packEvent(String type, String code, String text) {
        JSONObject obj = event(type, text);
        try {obj.put("code", code);}catch(Exception ignored){}
        return obj;
    }
    private void sendService(String action) {
        Intent intent = new Intent(this, ListeningService.class).setAction(action);
        startService(intent);
    }
    private void startListening(String src, String dst, boolean speak, String voice, double speed) {
        Intent intent = new Intent(this, ListeningService.class).setAction(ListeningService.ACTION_START);
        intent.putExtra("source", src); intent.putExtra("target", dst);
        intent.putExtra("speak", speak); intent.putExtra("voice", voice); intent.putExtra("speed", (float)speed);
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestedStart = intent;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION_REQUEST);
        } else {
            startForegroundService(intent);
        }
    }
    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == MIC_PERMISSION_REQUEST) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED && requestedStart != null)
                startForegroundService(requestedStart);
            else emit(event("error", "Microphone permission is required to listen."));
            requestedStart = null;
        }
    }
    @Override protected void onResume() {super.onResume(); current = new WeakReference<>(this); if(loaded)refreshAll();}
    @Override protected void onDestroy() { if (current.get() == this) current.clear(); if(web != null){web.removeJavascriptInterface("Android");web.destroy();web=null;} super.onDestroy();}

    final class Bridge {
        @JavascriptInterface public void getPacks() {main.post(MainActivity.this::loadPacks);}
        @JavascriptInterface public void downloadPack(String code, boolean wifi) { download(code, wifi); }
        @JavascriptInterface public void removePack(String code) { remove(code); }
        @JavascriptInterface public void sync() {main.post(MainActivity.this::refreshAll);}
        @JavascriptInterface public void start(String src, String dst, boolean speak, String voice, double speed) {
            main.post(() -> startListening(src, dst, speak, voice, speed));
        }
        @JavascriptInterface public void stop() {main.post(() -> sendService(ListeningService.ACTION_STOP));}
        @JavascriptInterface public void pause() {main.post(() -> sendService(ListeningService.ACTION_PAUSE));}
        @JavascriptInterface public void resume() {main.post(() -> sendService(ListeningService.ACTION_RESUME));}
        @JavascriptInterface public void replay() {main.post(() -> sendService(ListeningService.ACTION_REPLAY));}
        @JavascriptInterface public void clear() { main.post(() -> { getSharedPreferences("ambient",MODE_PRIVATE).edit().remove("history").apply(); emit(event("history_cleared", "History cleared")); }); }
    }
}
