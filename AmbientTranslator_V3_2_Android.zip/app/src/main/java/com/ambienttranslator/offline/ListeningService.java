package com.ambienttranslator.offline;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;

import com.google.mlkit.common.model.RemoteModelManager;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.TranslateRemoteModel;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import org.json.JSONArray;
import org.json.JSONObject;
import org.vosk.Model;
import org.vosk.Recognizer;
import org.vosk.android.SpeechService;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ListeningService extends Service {
    public static final String ACTION_START = "ambient.start";
    public static final String ACTION_STOP = "ambient.stop";
    public static final String ACTION_PAUSE = "ambient.pause";
    public static final String ACTION_RESUME = "ambient.resume";
    public static final String ACTION_REPLAY = "ambient.replay";
    private static final String CHANNEL = "ambient_listen";
    private static final int NOTIFICATION_ID = 4123;
    private static ListeningService instance;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private SpeechService voskSpeech;
    private Model voskModel;
    private SpeechRecognizer recognizer;
    private Translator translator;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private boolean offlineVoiceAvailable = false;
    private boolean running = false, paused = false, recording = false, startingModel = false;
    private boolean speak = true;
    private String source = "es-MX", target = "en", voiceChoice = "kristin";
    private float voiceSpeed = 1f;
    private String heard = "", translation = "";
    private final ArrayDeque<String> pending = new ArrayDeque<>();
    private boolean translating = false;

    public static JSONObject snapshot(android.content.Context context) {
        ListeningService service = instance;
        JSONObject obj = new JSONObject();
        try {
            obj.put("type", "sync");
            obj.put("running", service != null && service.running);
            obj.put("paused", service != null && service.paused);
            obj.put("source", service != null ? service.source : "es-MX");
            obj.put("target", service != null ? service.target : "en");
            obj.put("voiceChoice", service != null ? service.voiceChoice : "kristin");
            obj.put("voiceSpeed", service != null ? service.voiceSpeed : 1f);
            obj.put("heard", service != null ? service.heard : "");
            obj.put("translation", service != null ? service.translation : "");
            obj.put("history", context.getSharedPreferences("ambient", MODE_PRIVATE).getString("history", "[]"));
        } catch (Exception ignored) {}
        return obj;
    }

    @Override public void onCreate() {
        super.onCreate(); instance = this;
        NotificationChannel channel = new NotificationChannel(CHANNEL,"Ambient listening", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Persistent on-device speech recognition while translation is active");
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
        tts = new TextToSpeech(getApplicationContext(), state -> {
            ttsReady = state == TextToSpeech.SUCCESS;
            if (ttsReady) {tts.setLanguage(Locale.US); selectOfflineVoice();}
        });
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? "" : intent.getAction();
        if (ACTION_START.equals(action)) {
            stopRecognition(); releaseTranslator();
            source = intent.getStringExtra("source") == null ? "es-MX" : intent.getStringExtra("source");
            target = intent.getStringExtra("target") == null ? "en" : intent.getStringExtra("target");
            voiceChoice = intent.getStringExtra("voice") == null ? "kristin" : intent.getStringExtra("voice");
            voiceSpeed = intent.getFloatExtra("speed",1f);
            speak = intent.getBooleanExtra("speak",true);
            running = true; paused = false; pending.clear(); translating = false;
            startForeground(NOTIFICATION_ID, notification(),ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            publishState();
            prepare();
        } else if(ACTION_STOP.equals(action)) {
            stopEverything(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf();
        } else if (ACTION_PAUSE.equals(action)) {
            if(running && !paused) {paused = true; stopRecognition(); updateNotification(); publishState(); broadcast("status", "Paused · microphone off");}
        } else if (ACTION_RESUME.equals(action)) {
            if(running && paused) {paused = false; updateNotification(); publishState(); prepare();}
        } else if (ACTION_REPLAY.equals(action)) {
            readAloud(translation);
        }
        return START_NOT_STICKY; // Never restart microphone recording without a user action.
    }

    private Notification notification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openIntent = PendingIntent.getActivity(this, 100, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 101,
            new Intent(this,ListeningService.class).setAction(ACTION_STOP),PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent toggle = PendingIntent.getService(this,102,
            new Intent(this,ListeningService.class).setAction(paused?ACTION_RESUME:ACTION_PAUSE),PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String desc = paused ? "Paused" : (source.startsWith("es") ? "Spanish" : source) + " → " + target + " · processing on device";
        return new Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("Ambient Translator")
            .setContentText(desc).setOngoing(true).setContentIntent(openIntent)
            .addAction(new Notification.Action.Builder(null, paused?"Resume":"Pause", toggle).build())
            .addAction(new Notification.Action.Builder(null,"Stop",stop).build()).build();
    }
    private void updateNotification() {getSystemService(NotificationManager.class).notify(NOTIFICATION_ID,notification());}
    private void publishState() {MainActivity.emit(snapshot(this));}
    private void broadcast(String type,String message){MainActivity.emit(MainActivity.event(type,message));}
    private void error(String text) {broadcast("error", text);broadcast("status",text);}

    private void prepare() {
        if (!running || paused || recording || startingModel) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            error("Microphone permission not granted"); stopEverything(); stopSelf(); return;
        }
        String a = base(source), b = base(target);
        if (a.equals(b)) { beginRecording(); return; }
        RemoteModelManager.getInstance().getDownloadedModels(TranslateRemoteModel.class)
            .addOnSuccessListener(models -> {
                if (!running || paused) return;
                boolean srcReady = a.equals("en") || hasModel(models,a);
                boolean dstReady = b.equals("en") || hasModel(models,b);
                if (!srcReady || !dstReady) {
                    error("Missing text translation pack. Download it from Language Library first.");
                    stopEverything(); stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return;
                }
                try {
                    String src = TranslateLanguage.fromLanguageTag(a);
                    String dst = TranslateLanguage.fromLanguageTag(b);
                    if(src == null || dst == null) throw new IllegalArgumentException("Unsupported language pair");
                    translator=Translation.getClient(new TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(dst).build());
                    beginRecording();
                } catch(Exception ex) {
                    error("Translator initialization failed: " + ex.getMessage()); stopEverything();stopSelf();
                }
            })
            .addOnFailureListener(ex -> {error("Unable to check offline translation models: "+ex.getMessage()); stopEverything(); stopSelf();});
    }
    private String base(String code) {return code.split("-")[0].toLowerCase(Locale.ROOT);}
    private boolean hasModel(Set<TranslateRemoteModel> models, String code) {
        for (TranslateRemoteModel model : models) if(code.equals(model.getLanguage())) return true;
        return false;
    }
    private void beginRecording() {
        if (!running || paused || recording || startingModel) return;
        if (base(source).equals("es")) beginVosk(); else beginAndroidRecognizer();
    }

    private void beginVosk() {
        if (voskModel != null) { startVoskStream(); return; }
        startingModel = true;
        broadcast("status", "Loading included Spanish speech engine…");
        worker.execute(() -> {
            try {
                File path = new File(getFilesDir(), "vosk-spanish-model-v1");
                // Only bundled APK assets are used; model isn't fetched from the web at runtime.
                if(!new File(path,"am/final.mdl").exists()) copyAssetTree("models/es",path);
                Model loaded = new Model(path.getAbsolutePath());
                main.post(() -> {
                    startingModel = false;
                    if(!running || paused){loaded.close();return;}
                    voskModel=loaded;
                    startVoskStream();
                });
            }catch(Exception e){
                main.post(() -> {
                    startingModel=false;
                    error("Bundled Spanish speech model unavailable: "+e.getMessage());
                    stopEverything();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
                });
            }
        });
    }
    private void copyAssetTree(String root, File dest) throws Exception {
        String[] names = getAssets().list(root);
        if(names == null || names.length==0) {
            dest.getParentFile().mkdirs();
            try(InputStream in=getAssets().open(root);FileOutputStream out=new FileOutputStream(dest)){
                byte[] buffer=new byte[32768];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
            }
        } else {
            if (!dest.exists()&&!dest.mkdirs())throw new java.io.IOException("Cannot create model directory");
            for(String name:names) copyAssetTree(root+"/"+name,new File(dest,name));
        }
    }
    private void startVoskStream() {
        try {
            Recognizer v = new Recognizer(voskModel,16000f);
            voskSpeech=new SpeechService(v,16000f);
            recording=true;
            voskSpeech.startListening(new org.vosk.android.RecognitionListener() {
                @Override public void onPartialResult(String hypothesis) {
                    // partial text is not translated: it would create duplicate history entries
                }
                @Override public void onResult(String hypothesis) {readVosk(hypothesis);}
                @Override public void onFinalResult(String hypothesis) {readVosk(hypothesis);}
                @Override public void onError(Exception ex) {main.post(()->error("Speech recognition error: "+ex.getMessage()));}
                @Override public void onTimeout() {}
            });
            broadcast("status","Listening offline · Spanish microphone active");
        }catch(Exception e){error("Spanish speech engine failed: "+e.getMessage());stopEverything();stopSelf();}
    }
    private void readVosk(String response) {
        try{
            String words=new JSONObject(response).optString("text", "").trim();
            if(!words.isEmpty()) main.post(()->processSentence(words));
        }catch(Exception ignored){}
    }

    private void beginAndroidRecognizer() {
        if(!SpeechRecognizer.isOnDeviceRecognitionAvailable(this)){
            error("On-device recognition not installed for this phone. No cloud fallback is used.");
            stopEverything();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return;
        }
        try {
            recognizer=SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle b) {broadcast("status","Listening offline · "+source);}
                @Override public void onBeginningOfSpeech() {}
                @Override public void onRmsChanged(float rms) {}
                @Override public void onBufferReceived(byte[] buffer) {}
                @Override public void onEndOfSpeech() {}
                @Override public void onPartialResults(Bundle b) {}
                @Override public void onEvent(int type, Bundle params) {}
                @Override public void onResults(Bundle b) {
                    java.util.ArrayList<String> results=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if(results != null && !results.isEmpty()) processSentence(results.get(0));
                    scheduleRestart(250);
                }
                @Override public void onError(int code) {
                    // Fail safe on missing speech language instead of switching to online recognition.
                    if(code==SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED || code==SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE || code==SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        error("Offline speech language unavailable (code "+code+"). Install its on-device voice model in Android settings.");
                        stopEverything();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
                    } else scheduleRestart(850);
                }
            });
            recording=true; listenOnce();
        }catch(Exception e){error("Unable to start on-device recognition: "+e.getMessage());stopEverything();stopSelf();}
    }
    private void listenOnce() {
        if(!recording||paused||!running||recognizer==null)return;
        Intent intent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,source);
        intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,true);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false);
        try{recognizer.startListening(intent);}catch(Exception e){error("Speech recognizer error: "+e.getMessage());}
    }
    private void scheduleRestart(long delay) {
        main.postDelayed(() -> {
            if(!recording||paused||!running||recognizer==null)return;
            try{recognizer.cancel();listenOnce();}catch(Exception e){error("Recognition restart failed: "+e.getMessage());}
        },delay);
    }
    private void processSentence(String text) {
        if(!running||paused||text.trim().isEmpty())return;
        heard=text.trim(); broadcast("heard",heard);
        pending.add(heard);
        drainTranslations();
    }
    private void drainTranslations() {
        if(translating||pending.isEmpty()||!running||paused)return;
        String input=pending.poll();
        translating=true;
        if(base(source).equals(base(target))) {
            completedTranslation(input,input);return;
        }
        if(translator==null) {translating=false;error("Translation model not initialized");return;}
        translator.translate(input).addOnSuccessListener(text->completedTranslation(input,text))
            .addOnFailureListener(err->{
                translating=false;error("Offline translation unavailable: "+err.getMessage());drainTranslations();
            });
    }
    private void completedTranslation(String original,String result) {
        translation=result;
        heard=original;
        // Emit matching heard event first, then translation for correct browser history.
        broadcast("heard",original);
        broadcast("translation",result);
        try {
            JSONArray old=new JSONArray(getSharedPreferences("ambient",MODE_PRIVATE).getString("history","[]"));
            JSONArray fresh=new JSONArray();
            JSONObject item=new JSONObject();item.put("date",new java.text.SimpleDateFormat("MMM d, h:mm a",Locale.getDefault()).format(new java.util.Date()));
            item.put("original",original);item.put("translated",result);fresh.put(item);
            for(int i=0;i<Math.min(old.length(),49);i++)fresh.put(old.get(i));
            getSharedPreferences("ambient",MODE_PRIVATE).edit().putString("history",fresh.toString()).apply();
        }catch(Exception ignored){}
        if(speak&&base(target).equals("en"))readAloud(result);
        translating=false;drainTranslations();
    }
    private void selectOfflineVoice() {
        offlineVoiceAvailable = false;
        if(!ttsReady||tts==null)return;
        Set<Voice> voices=tts.getVoices();if(voices==null)return;
        Voice best=null;
        for(Voice voice:voices){
            if(!voice.getLocale().getLanguage().equals("en")||voice.isNetworkConnectionRequired())continue;
            String name=voice.getName().toLowerCase(Locale.ROOT);
            boolean preferred="john".equals(voiceChoice)?(name.contains("male")&&!name.contains("female")):(name.contains("female")||name.contains("fem"));
            if(best==null || preferred){best=voice;if(preferred)break;}
        }
        if(best!=null){tts.setVoice(best);offlineVoiceAvailable = true;}
        tts.setSpeechRate(Math.max(0.5f,Math.min(2f,voiceSpeed)));
    }
    private void readAloud(String text) {
        if(!ttsReady||tts==null||text==null||text.isBlank()||!base(target).equals("en"))return;
        selectOfflineVoice();
        if(!offlineVoiceAvailable){broadcast("status","No offline English text-to-speech voice is installed. Captions will continue.");return;}
        tts.speak(text,TextToSpeech.QUEUE_ADD,null,"ambient-"+System.nanoTime());
    }
    private void stopRecognition() {
        recording=false;
        if(voskSpeech!=null){try{voskSpeech.stop();voskSpeech.shutdown();}catch(Exception ignored){}voskSpeech=null;}
        if(recognizer!=null){try{recognizer.cancel();recognizer.destroy();}catch(Exception ignored){}recognizer=null;}
    }
    private void releaseTranslator(){if(translator!=null){translator.close();translator=null;}}
    private void stopEverything() {
        running=false; paused=false; startingModel=false; stopRecognition(); releaseTranslator();
        pending.clear();translating=false;
        if(tts!=null)tts.stop();publishState();
    }
    @Override public void onDestroy(){stopEverything();if(voskModel!=null){voskModel.close();voskModel=null;}if(tts!=null){tts.shutdown();tts=null;}worker.shutdownNow();instance=null;super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
