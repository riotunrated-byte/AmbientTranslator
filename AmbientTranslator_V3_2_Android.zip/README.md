# Ambient Translator V3.2 — Android

An offline-first Android version of the supplied **AmbientTranslator_V3_2_Language_Library_Preview.html**, with its visual UI preserved.

## What is actually implemented

- **Spanish microphone capture without internet:** the GitHub Actions APK build bundles the official Spanish Vosk small model (39 MB compressed, Apache 2.0). The model is copied to private app storage at first listening and transcribes Spanish offline. The speech recognition service runs with a visible ongoing Android microphone notification and Pause / Stop actions so listening can continue while the screen is not in front.
- **English / other-language recognition:** uses Android's `createOnDeviceSpeechRecognizer()` only. Whether speech recognition works depends on **on-device speech packs already installed on that device**. There is NO network speech fallback.
- **Language library:** ML Kit translation models may be downloaded on demand by tapping Download, optionally Wi-Fi-only, and removed individually. Downloaded packs are stored and reused locally. The Spanish **translation** model requires a one-time download too, even though the Spanish **speech** model is bundled.
- **Spanish → English:** Once the Spanish ML Kit text model has been downloaded, the Spanish speech engine transcribes audio offline, ML Kit translates the text offline, and Android TTS speaks English if an offline English voice exists on the phone.
- **Multiple language pairs:** when appropriate ML Kit packs and on-device speech recognizer support exist. Other-language voice synthesis is not bundled.
- Local translation history (stored by WebView + SharedPreferences) and microphone notification stop/pause.

**Limits:** The attached HTML preview alone had no native speech/translation engine or Whisper model. This Android project adds a working native bridge and uses a bundled Vosk Spanish model instead. **No full-size local Whisper model is supplied.** The current app does not implement automatic ambient language detection, translating multiple simultaneous voices, or perfect uninterrupted speech recognition across Android devices. Background operation depends on Android microphone foreground-service rules and battery management. Spanish text translation needs a one-time ML Kit model download; this cannot be described as “offline from the very first launch.”

## Build with GitHub Actions

1. Create a GitHub repository, e.g. `AmbientTranslator`.
2. Upload `AmbientTranslator_V3_2_Android.zip` to its root on `main` (do not unzip this upload).
3. Commit the standalone `.github/workflows/build-ambient-translator.yml` file at **exactly** that path, using the supplied prefilled link / workflow.
4. Open GitHub Actions → `Build Ambient Translator V3.2 APK`, then download the successful `AmbientTranslator-V3.2-APK` build artifact and extract `app-debug.apk`.

Build requires network access **only on GitHub's build runner** for Android dependencies and the Spanish Vosk model. The installed app needs internet only for initial **user-requested** ML Kit translation model downloads.

Or open the extracted project in Android Studio; first put the licensed model contents in `app/src/main/assets/models/es/` (see workflow for the exact location) before compiling.

Package name `com.ambienttranslator.offline`; version name `3.2.0`; Android API 31+.

### Licenses and sources

- [Vosk](https://alphacephei.com/vosk/) and [Spanish Vosk model](https://alphacephei.com/vosk/models): Apache 2.0 model.
- [Google ML Kit on-device translation](https://developers.google.com/ml-kit/language/translation/android): current `com.google.mlkit:translate:17.0.3`.
- Android's own on-device SpeechRecognizer and TextToSpeech APIs.
